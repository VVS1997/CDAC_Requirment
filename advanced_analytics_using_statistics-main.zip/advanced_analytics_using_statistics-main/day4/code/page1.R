v1 = c(10, 15, 18, 20, 25)
v2 = c(18, 20, 30, 35, 40)
covariance = cov(v1, v2)
print(covariance)
