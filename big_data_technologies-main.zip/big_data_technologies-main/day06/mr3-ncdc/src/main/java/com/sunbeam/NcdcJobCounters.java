package com.sunbeam;

public enum NcdcJobCounters {
	VALID_READING, INVALID_READING, INVALID_RECORD
}
